﻿using AssignmentCRUDOperation_CoreMVC.Models;
using Microsoft.AspNetCore.Mvc;

namespace AssignmentCRUDOperation_CoreMVC.Controllers
{
    
    public class StudentMVCController : Controller
    {
        
        public IActionResult Index()
        {
            return View();
        }
        HttpClient client = new HttpClient();
        HttpResponseMessage response;
        IList<Student> studentlist = new List<Student>();
        public StudentMVCController()
        {
            client.BaseAddress = new Uri("https://localhost:7144/");

        }
        public IActionResult GetStudentsMVC()
        {
            response = client.GetAsync("api/Student/GetStudents").Result;
            studentlist = response.Content.ReadAsAsync<IList<Student>>().Result;
            return View(studentlist);
        }
    }
}
