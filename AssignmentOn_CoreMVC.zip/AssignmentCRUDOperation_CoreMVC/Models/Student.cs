﻿namespace AssignmentCRUDOperation_CoreMVC.Models
{
    public class Student
    {
        public int Studentid { get; set; }
        public string Studentname { get; set; }
        public string Studentbranch { get; set; }
        public string Studentsubject { get; set; }

    }
}
