﻿using AssignmentCRUDOperations_WebApi.DataLayer;
using AssignmentCRUDOperations_WebApi.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using OpenXmlPowerTools;

namespace AssignmentCRUDOperations_WebApi.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class StudentController : ControllerBase
    {
        private readonly StudentContext _dbContext;
        public StudentController(StudentContext dbContext)
        {
            _dbContext = dbContext;
        }
        [HttpGet]
        public ActionResult<IEnumerable<Student>> GetStudents()
        {
            return _dbContext.Students.ToList();
        }
        [HttpGet("{id}")]
        public ActionResult<Student> GetStudentsByID(int id)
        {
            return _dbContext.Students.Find(id);
        }
        [HttpPost]
        public async Task<ActionResult<string>> AddStudent(Student s)
        {
            var Student = new Student
            {
                Studentname = s.Studentname,

                Studentsubject = s.Studentsubject,
                Studentbranch = s.Studentbranch,
            };
            _dbContext.Students.Add(Student);
            //  _dbContext.SaveChangesAsync();
            _dbContext.SaveChanges();
            return "Student Added Successfully";
        }
        [HttpDelete("{id}")]
        public ActionResult<string> DeleteStudentByID(int Studentid)
        {
            if (Student.DeleteStudents(Studentid)) 
            { 
                return Ok(true); 
            }
            else 
            { 
                return BadRequest(); 
            }
        }
    }
}
