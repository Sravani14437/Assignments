﻿namespace AssignmentCRUDOperations_WebApi.Models
{
    public class Student
    {
       public int Studentid { get; set; }
        public string Studentname { get; set; }
        public string Studentbranch { get; set; }
        public string Studentsubject { get; set; }

        internal static bool DeleteStudents(int studentid)
        {
            throw new NotImplementedException();
        }
    }
}
